import { 
  users, attractions, badges, userBadges, checkIns, photos, chatSessions, transportBookings,
  type User, type InsertUser, type Attraction, type InsertAttraction, 
  type Badge, type InsertBadge, type UserBadge, type CheckIn, type InsertCheckIn,
  type Photo, type InsertPhoto, type ChatSession, type InsertChatSession,
  type TransportBooking, type InsertTransportBooking
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLocation(userId: string, location: {lat: number, lng: number, name?: string}): Promise<void>;
  updateUserPoints(userId: string, points: number): Promise<User>;

  // Attraction operations
  getAttractions(): Promise<Attraction[]>;
  getAttractionsByCategory(category: string): Promise<Attraction[]>;
  getAttraction(id: string): Promise<Attraction | undefined>;
  createAttraction(attraction: InsertAttraction): Promise<Attraction>;
  incrementVisitCount(attractionId: string): Promise<void>;

  // Badge operations
  getBadges(): Promise<Badge[]>;
  getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]>;
  createUserBadge(userId: string, badgeId: string, progress?: Record<string, number>): Promise<UserBadge>;
  updateBadgeProgress(userId: string, badgeId: string, progress: Record<string, number>): Promise<void>;

  // Check-in operations
  createCheckIn(checkIn: InsertCheckIn): Promise<CheckIn>;
  getUserCheckIns(userId: string): Promise<(CheckIn & { attraction: Attraction })[]>;

  // Photo operations
  createPhoto(photo: InsertPhoto): Promise<Photo>;
  getUserPhotos(userId: string): Promise<Photo[]>;
  getAttractionPhotos(attractionId: string): Promise<(Photo & { user: User })[]>;

  // Chat operations
  getChatSession(userId: string): Promise<ChatSession | undefined>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  updateChatSession(id: string, sessionData: any): Promise<void>;

  // Transport operations
  createTransportBooking(booking: InsertTransportBooking): Promise<TransportBooking>;
  getUserTransportBookings(userId: string): Promise<TransportBooking[]>;
  updateBookingStatus(id: string, status: string, externalId?: string): Promise<void>;

  // Leaderboard and stats
  getLeaderboard(limit?: number): Promise<Array<User & { rank: number }>>;
  getUserStats(userId: string): Promise<{
    totalCheckIns: number;
    totalPhotos: number;
    totalBadges: number;
    totalPoints: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserLocation(userId: string, location: {lat: number, lng: number, name?: string}): Promise<void> {
    await db.update(users).set({ currentLocation: location }).where(eq(users.id, userId));
  }

  async updateUserPoints(userId: string, points: number): Promise<User> {
    const [user] = await db.update(users)
      .set({ totalPoints: sql`${users.totalPoints} + ${points}` })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getAttractions(): Promise<Attraction[]> {
    return await db.select().from(attractions).orderBy(attractions.visitCount);
  }

  async getAttractionsByCategory(category: string): Promise<Attraction[]> {
    return await db.select().from(attractions)
      .where(eq(attractions.category, category))
      .orderBy(attractions.visitCount);
  }

  async getAttraction(id: string): Promise<Attraction | undefined> {
    const [attraction] = await db.select().from(attractions).where(eq(attractions.id, id));
    return attraction || undefined;
  }

  async createAttraction(attraction: InsertAttraction): Promise<Attraction> {
    const [newAttraction] = await db.insert(attractions).values(attraction).returning();
    return newAttraction;
  }

  async incrementVisitCount(attractionId: string): Promise<void> {
    await db.update(attractions)
      .set({ visitCount: sql`${attractions.visitCount} + 1` })
      .where(eq(attractions.id, attractionId));
  }

  async getBadges(): Promise<Badge[]> {
    return await db.select().from(badges).orderBy(badges.category, badges.points);
  }

  async getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]> {
    const rows = await db.select({ ub: userBadges, b: badges })
      .from(userBadges)
      .innerJoin(badges, eq(userBadges.badgeId, badges.id))
      .where(eq(userBadges.userId, userId))
      .orderBy(desc(userBadges.earnedAt));
    return rows.map(({ ub, b }) => ({ ...ub, badge: b }));
  }

  async createUserBadge(userId: string, badgeId: string, progress?: Record<string, number>): Promise<UserBadge> {
    const [userBadge] = await db.insert(userBadges)
      .values({ userId, badgeId, progress: progress || {} })
      .returning();
    return userBadge;
  }

  async updateBadgeProgress(userId: string, badgeId: string, progress: Record<string, number>): Promise<void> {
    await db.update(userBadges)
      .set({ progress })
      .where(and(eq(userBadges.userId, userId), eq(userBadges.badgeId, badgeId)));
  }

  async createCheckIn(checkIn: InsertCheckIn): Promise<CheckIn> {
    const [newCheckIn] = await db.insert(checkIns).values(checkIn).returning();
    return newCheckIn;
  }

  async getUserCheckIns(userId: string): Promise<(CheckIn & { attraction: Attraction })[]> {
    const rows = await db.select({ ci: checkIns, a: attractions })
      .from(checkIns)
      .innerJoin(attractions, eq(checkIns.attractionId, attractions.id))
      .where(eq(checkIns.userId, userId))
      .orderBy(desc(checkIns.timestamp));
    return rows.map(({ ci, a }) => ({ ...ci, attraction: a }));
  }

  async createPhoto(photo: InsertPhoto): Promise<Photo> {
    const [newPhoto] = await db.insert(photos).values([photo]).returning();
    return newPhoto;
  }

  async getUserPhotos(userId: string): Promise<Photo[]> {
    return await db.select().from(photos)
      .where(eq(photos.userId, userId))
      .orderBy(desc(photos.uploadedAt));
  }

  async getAttractionPhotos(attractionId: string): Promise<(Photo & { user: User })[]> {
    const rows = await db.select({ p: photos, u: users })
      .from(photos)
      .innerJoin(users, eq(photos.userId, users.id))
      .where(eq(photos.attractionId, attractionId))
      .orderBy(desc(photos.uploadedAt));
    return rows.map(({ p, u }) => ({ ...p, user: u }));
  }

  async getChatSession(userId: string): Promise<ChatSession | undefined> {
    const [session] = await db.select().from(chatSessions)
      .where(eq(chatSessions.userId, userId))
      .orderBy(desc(chatSessions.updatedAt))
      .limit(1);
    return session || undefined;
  }

  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const [newSession] = await db.insert(chatSessions).values([session]).returning();
    return newSession;
  }

  async updateChatSession(id: string, sessionData: any): Promise<void> {
    await db.update(chatSessions)
      .set({ sessionData, updatedAt: new Date() })
      .where(eq(chatSessions.id, id));
  }

  async createTransportBooking(booking: InsertTransportBooking): Promise<TransportBooking> {
    const [newBooking] = await db.insert(transportBookings).values(booking).returning();
    return newBooking;
  }

  async getUserTransportBookings(userId: string): Promise<TransportBooking[]> {
    return await db.select().from(transportBookings)
      .where(eq(transportBookings.userId, userId))
      .orderBy(desc(transportBookings.createdAt));
  }

  async updateBookingStatus(id: string, status: string, externalId?: string): Promise<void> {
    await db.update(transportBookings)
      .set({ status, externalBookingId: externalId })
      .where(eq(transportBookings.id, id));
  }

  async getLeaderboard(limit = 10): Promise<Array<User & { rank: number }>> {
    const results = await db.select()
      .from(users)
      .orderBy(desc(users.totalPoints))
      .limit(limit);
    
    return results.map((user, index) => ({ ...user, rank: index + 1 }));
  }

  async getUserStats(userId: string): Promise<{
    totalCheckIns: number;
    totalPhotos: number;
    totalBadges: number;
    totalPoints: number;
  }> {
    const [user] = await db.select({ totalPoints: users.totalPoints })
      .from(users)
      .where(eq(users.id, userId));

    const [checkInCount] = await db.select({ count: count() })
      .from(checkIns)
      .where(eq(checkIns.userId, userId));

    const [photoCount] = await db.select({ count: count() })
      .from(photos)
      .where(eq(photos.userId, userId));

    const [badgeCount] = await db.select({ count: count() })
      .from(userBadges)
      .where(eq(userBadges.userId, userId));

    return {
      totalCheckIns: checkInCount.count,
      totalPhotos: photoCount.count,
      totalBadges: badgeCount.count,
      totalPoints: user?.totalPoints || 0,
    };
  }
}

export const storage = new DatabaseStorage();
