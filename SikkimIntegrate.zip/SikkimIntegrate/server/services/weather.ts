export interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  forecast: Array<{
    date: string;
    high: number;
    low: number;
    condition: string;
  }>;
}

export interface RoadCondition {
  route: string;
  status: 'good' | 'moderate' | 'poor' | 'closed';
  description: string;
  lastUpdated: string;
}

export async function getWeatherData(location: string): Promise<WeatherData> {
  // Using OpenWeatherMap API (free tier available)
  const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY || "demo_key";
  
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)},IN&appid=${apiKey}&units=metric`
    );
    
    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Get 5-day forecast
    const forecastResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(location)},IN&appid=${apiKey}&units=metric`
    );
    
    const forecastData = forecastResponse.ok ? await forecastResponse.json() : null;
    
    const forecast = forecastData?.list?.slice(0, 5).map((item: any) => ({
      date: new Date(item.dt * 1000).toISOString().split('T')[0],
      high: Math.round(item.main.temp_max),
      low: Math.round(item.main.temp_min),
      condition: item.weather[0]?.main || 'Unknown'
    })) || [];

    return {
      location: data.name || location,
      temperature: Math.round(data.main?.temp || 0),
      condition: data.weather?.[0]?.main || 'Unknown',
      humidity: data.main?.humidity || 0,
      windSpeed: data.wind?.speed || 0,
      visibility: (data.visibility || 10000) / 1000, // Convert to km
      forecast
    };
  } catch (error) {
    console.error("Weather API error:", error);
    
    // Fallback data for demo purposes
    return {
      location: location,
      temperature: 18,
      condition: "Partly Cloudy",
      humidity: 65,
      windSpeed: 5.2,
      visibility: 8.5,
      forecast: [
        { date: new Date().toISOString().split('T')[0], high: 20, low: 12, condition: "Sunny" },
        { date: new Date(Date.now() + 86400000).toISOString().split('T')[0], high: 18, low: 10, condition: "Cloudy" },
        { date: new Date(Date.now() + 172800000).toISOString().split('T')[0], high: 15, low: 8, condition: "Rain" },
      ]
    };
  }
}

export async function getRoadConditions(route?: string): Promise<RoadCondition[]> {
  // This would integrate with local traffic/road condition APIs
  // For now, returning structured data that would come from such APIs
  
  const majorRoutes: RoadCondition[] = [
    {
      route: "Gangtok to Tsomgo Lake",
      status: "good",
      description: "Clear roads, normal traffic conditions",
      lastUpdated: new Date().toISOString()
    },
    {
      route: "Gangtok to Nathu La Pass",
      status: "moderate",
      description: "Permit required, check weather conditions",
      lastUpdated: new Date().toISOString()
    },
    {
      route: "Gangtok to Pelling",
      status: "good",
      description: "Good road conditions, approximately 4 hours drive",
      lastUpdated: new Date().toISOString()
    },
    {
      route: "Yuksom to Dzongri Trek",
      status: "moderate",
      description: "Trekking route, guide recommended",
      lastUpdated: new Date().toISOString()
    }
  ];

  if (route) {
    return majorRoutes.filter(r => 
      r.route.toLowerCase().includes(route.toLowerCase())
    );
  }

  return majorRoutes;
}

export async function getAltitudeWeather(altitude: number): Promise<{
  temperature: number;
  warning?: string;
}> {
  // Calculate temperature drop with altitude (approx 6.5°C per 1000m)
  const baseTemp = 20; // Base temperature at sea level
  const altitudeInKm = altitude / 1000;
  const temperatureDrop = altitudeInKm * 6.5;
  const adjustedTemp = baseTemp - temperatureDrop;

  let warning = undefined;
  if (altitude > 3500) {
    warning = "High altitude: Risk of altitude sickness. Ascend gradually and stay hydrated.";
  } else if (altitude > 2500) {
    warning = "Moderate altitude: Take time to acclimatize.";
  }

  return {
    temperature: Math.round(adjustedTemp),
    warning
  };
}
