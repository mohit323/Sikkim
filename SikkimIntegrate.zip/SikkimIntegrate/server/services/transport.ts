export interface TransportOption {
  provider: string;
  type: 'cab' | 'bus' | 'shared' | 'bike';
  estimatedPrice: number;
  estimatedTime: string;
  availability: 'available' | 'limited' | 'unavailable';
  features: string[];
  externalUrl?: string;
}

export interface BookingRequest {
  fromLocation: { lat: number; lng: number; name: string };
  toLocation: { lat: number; lng: number; name: string };
  bookingTime: Date;
  transportType: string;
  passengers?: number;
}

export async function getTransportOptions(
  from: { lat: number; lng: number; name: string },
  to: { lat: number; lng: number; name: string }
): Promise<TransportOption[]> {
  
  // Calculate distance for pricing estimates
  const distance = calculateDistance(from, to);
  
  const options: TransportOption[] = [
    {
      provider: "Ola",
      type: "cab",
      estimatedPrice: Math.round(distance * 12 + 50), // Base fare + per km
      estimatedTime: `${Math.round(distance / 30 * 60)} min`,
      availability: "available",
      features: ["GPS tracking", "24/7 support", "Cashless payment"],
      externalUrl: `https://book.olacabs.com/?pickup=${from.name}&drop=${to.name}`
    },
    {
      provider: "Uber",
      type: "cab",
      estimatedPrice: Math.round(distance * 11 + 45),
      estimatedTime: `${Math.round(distance / 30 * 60)} min`,
      availability: "available",
      features: ["Real-time tracking", "In-app payment", "Driver ratings"],
      externalUrl: `https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${from.lat}&pickup[longitude]=${from.lng}&dropoff[latitude]=${to.lat}&dropoff[longitude]=${to.lng}`
    },
    {
      provider: "Local Shared Taxi",
      type: "shared",
      estimatedPrice: Math.round(distance * 4 + 20),
      estimatedTime: `${Math.round(distance / 25 * 60)} min`,
      availability: distance < 50 ? "available" : "limited",
      features: ["Eco-friendly", "Local experience", "Fixed routes"]
    },
    {
      provider: "SNT Bus Service",
      type: "bus",
      estimatedPrice: Math.round(distance * 2 + 10),
      estimatedTime: `${Math.round(distance / 20 * 60)} min`,
      availability: "limited",
      features: ["Government service", "Very affordable", "Regular schedule"]
    }
  ];

  // Filter based on distance and availability
  return options.filter(option => {
    if (distance > 100 && option.type === 'bike') return false;
    if (distance < 5 && option.type === 'bus') return false;
    return true;
  });
}

export async function initiateBooking(request: BookingRequest): Promise<{
  success: boolean;
  bookingId?: string;
  externalUrl?: string;
  message: string;
}> {
  try {
    // This would integrate with actual booking APIs
    // For Ola/Uber, we'd redirect to their deep links
    // For local services, we might have direct API integration
    
    if (request.transportType === 'ola') {
      const deepLink = `https://book.olacabs.com/?pickup=${encodeURIComponent(request.fromLocation.name)}&drop=${encodeURIComponent(request.toLocation.name)}&utm_source=sikkimvibes`;
      
      return {
        success: true,
        externalUrl: deepLink,
        message: "Redirecting to Ola for booking confirmation"
      };
    }
    
    if (request.transportType === 'uber') {
      const deepLink = `https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${request.fromLocation.lat}&pickup[longitude]=${request.fromLocation.lng}&dropoff[latitude]=${request.toLocation.lat}&dropoff[longitude]=${request.toLocation.lng}&utm_source=sikkimvibes`;
      
      return {
        success: true,
        externalUrl: deepLink,
        message: "Redirecting to Uber for booking confirmation"
      };
    }
    
    // For local services, we'd handle booking internally
    const bookingId = `LOCAL_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    
    return {
      success: true,
      bookingId,
      message: "Booking request submitted. Our partner will contact you shortly."
    };
    
  } catch (error) {
    console.error("Booking error:", error);
    return {
      success: false,
      message: "Unable to process booking request. Please try again."
    };
  }
}

export async function getBookingStatus(bookingId: string): Promise<{
  status: 'pending' | 'confirmed' | 'en_route' | 'completed' | 'cancelled';
  driver?: {
    name: string;
    phone: string;
    vehicle: string;
  };
  estimatedArrival?: string;
}> {
  // This would check status with external APIs
  // For demo, returning a dynamic status
  
  return {
    status: 'confirmed',
    driver: {
      name: "Tenzin Driver",
      phone: "+91-XXXXX-XXXXX",
      vehicle: "Maruti Swift (SK-01-AB-1234)"
    },
    estimatedArrival: "15 minutes"
  };
}

function calculateDistance(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number }
): number {
  const R = 6371; // Earth's radius in km
  const dLat = (to.lat - from.lat) * Math.PI / 180;
  const dLon = (to.lng - from.lng) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(from.lat * Math.PI / 180) * Math.cos(to.lat * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export async function getPermitInfo(destination: string): Promise<{
  required: boolean;
  type?: string;
  process?: string[];
  documents?: string[];
  fees?: string;
  validityDays?: number;
}> {
  const permitData: Record<string, any> = {
    "nathu la": {
      required: true,
      type: "Protected Area Permit",
      process: [
        "Apply at SNT counter in Gangtok",
        "Submit required documents",
        "Pay permit fees",
        "Collect permit 24 hours before travel"
      ],
      documents: ["Valid photo ID", "2 passport-size photos", "Travel itinerary"],
      fees: "₹20 per person",
      validityDays: 1
    },
    "gurudongmar": {
      required: true,
      type: "Inner Line Permit",
      process: [
        "Apply online or at DC office",
        "Group of minimum 4 required",
        "Advance booking mandatory"
      ],
      documents: ["Valid photo ID", "Medical certificate", "Group list"],
      fees: "₹50 per person",
      validityDays: 3
    }
  };

  const key = destination.toLowerCase();
  const info = permitData[key];

  if (info) {
    return { required: true, ...info };
  }

  return { required: false };
}
