import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface ChatResponse {
  message: string;
  suggestions?: string[];
  actions?: Array<{
    type: string;
    label: string;
    data?: any;
  }>;
}

export async function getChatResponse(
  message: string,
  context?: {
    userLocation?: { lat: number; lng: number; name?: string };
    userBadges?: string[];
    recentCheckIns?: string[];
  }
): Promise<ChatResponse> {
  try {
    const systemPrompt = `You are a helpful AI travel assistant for Sikkim, India. You help travelers with:
- Tourist attractions and destinations
- Weather conditions and road safety
- Permit requirements and documentation
- Transportation options and booking
- Cultural information and local customs
- Badge earning opportunities and progress
- Emergency assistance and local contacts

Always provide accurate, helpful, and culturally sensitive information about Sikkim tourism.
${context?.userLocation ? `User's current location: ${context.userLocation.name || 'Unknown'}` : ''}
${context?.userBadges?.length ? `User's badges: ${context.userBadges.join(', ')}` : ''}

Respond in JSON format with:
- message: Your helpful response
- suggestions: Array of 2-3 quick follow-up questions/topics
- actions: Array of helpful actions the user can take (check permits, view weather, book transport, etc.)`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      message: result.message || "I'm here to help you explore Sikkim! What would you like to know?",
      suggestions: result.suggestions || ["What permits do I need?", "Show me nearby attractions", "What's the weather like?"],
      actions: result.actions || []
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    return {
      message: "I'm experiencing some technical difficulties. Please try asking me something about Sikkim tourism!",
      suggestions: ["Popular attractions", "Weather updates", "Transportation"],
    };
  }
}

export async function analyzePhotoLocation(base64Image: string): Promise<{
  location: string;
  confidence: number;
  suggestions: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image and identify if it's from a tourist location in Sikkim, India. Respond in JSON format with: location (name of place if identifiable), confidence (0-1), suggestions (array of possible locations if uncertain)."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 300,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      location: result.location || "Unknown location",
      confidence: Math.max(0, Math.min(1, result.confidence || 0)),
      suggestions: result.suggestions || [],
    };
  } catch (error) {
    console.error("Photo analysis error:", error);
    return {
      location: "Unable to identify location",
      confidence: 0,
      suggestions: [],
    };
  }
}

export async function generateTravelTips(attraction: string, weather?: any): Promise<string[]> {
  try {
    const weatherContext = weather ? `Current weather: ${weather.condition}, ${weather.temperature}°C` : '';
    
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `Generate 3-5 helpful travel tips for visiting ${attraction} in Sikkim. ${weatherContext}. Respond in JSON format with an array of tip strings.`
        },
        {
          role: "user",
          content: `Give me travel tips for ${attraction}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.tips || [
      "Check weather conditions before traveling",
      "Carry valid ID for permits",
      "Respect local customs and traditions"
    ];
  } catch (error) {
    console.error("Travel tips generation error:", error);
    return [
      "Plan your visit during clear weather",
      "Bring warm clothing for high altitudes",
      "Stay hydrated and take rest breaks"
    ];
  }
}
