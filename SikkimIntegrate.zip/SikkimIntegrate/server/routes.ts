import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getChatResponse, analyzePhotoLocation, generateTravelTips } from "./services/openai";
import { getWeatherData, getRoadConditions, getAltitudeWeather } from "./services/weather";
import { getTransportOptions, initiateBooking, getBookingStatus, getPermitInfo } from "./services/transport";
import { insertCheckInSchema, insertPhotoSchema, insertChatSessionSchema, insertTransportBookingSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Attractions API
  app.get("/api/attractions", async (req, res) => {
    try {
      const category = req.query.category as string;
      const attractions = category 
        ? await storage.getAttractionsByCategory(category)
        : await storage.getAttractions();
      res.json(attractions);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch attractions: " + error.message });
    }
  });

  app.get("/api/attractions/:id", async (req, res) => {
    try {
      const attraction = await storage.getAttraction(req.params.id);
      if (!attraction) {
        return res.status(404).json({ message: "Attraction not found" });
      }
      res.json(attraction);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch attraction: " + error.message });
    }
  });

  // Check-in API
  app.post("/api/checkins", async (req, res) => {
    try {
      const checkInData = insertCheckInSchema.parse(req.body);
      const checkIn = await storage.createCheckIn(checkInData);
      
      // Award points and increment visit count
      const attraction = await storage.getAttraction(checkInData.attractionId);
      if (attraction) {
        await storage.updateUserPoints(checkInData.userId, attraction.badgePoints || 10);
        await storage.incrementVisitCount(checkInData.attractionId);
      }
      
      res.json(checkIn);
    } catch (error: any) {
      res.status(400).json({ message: "Failed to create check-in: " + error.message });
    }
  });

  app.get("/api/users/:userId/checkins", async (req, res) => {
    try {
      const checkIns = await storage.getUserCheckIns(req.params.userId);
      res.json(checkIns);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch check-ins: " + error.message });
    }
  });

  // Badge API
  app.get("/api/badges", async (req, res) => {
    try {
      const badges = await storage.getBadges();
      res.json(badges);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch badges: " + error.message });
    }
  });

  app.get("/api/users/:userId/badges", async (req, res) => {
    try {
      const userBadges = await storage.getUserBadges(req.params.userId);
      res.json(userBadges);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch user badges: " + error.message });
    }
  });

  // Photo API
  app.post("/api/photos", async (req, res) => {
    try {
      const photoData = insertPhotoSchema.parse(req.body);
      const photo = await storage.createPhoto(photoData);
      
      // Award points for photo upload
      await storage.updateUserPoints(photoData.userId, 15);
      
      res.json(photo);
    } catch (error: any) {
      res.status(400).json({ message: "Failed to upload photo: " + error.message });
    }
  });

  app.post("/api/photos/analyze", async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ message: "Image data required" });
      }
      
      const analysis = await analyzePhotoLocation(image);
      res.json(analysis);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to analyze photo: " + error.message });
    }
  });

  app.get("/api/users/:userId/photos", async (req, res) => {
    try {
      const photos = await storage.getUserPhotos(req.params.userId);
      res.json(photos);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch photos: " + error.message });
    }
  });

  // Chat API
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, userId, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const response = await getChatResponse(message, context);
      
      // Save chat session if userId provided
      if (userId) {
        let session = await storage.getChatSession(userId);
        
        const newMessage = {
          role: 'user',
          content: message,
          timestamp: Date.now()
        };
        
        const botResponse = {
          role: 'assistant',
          content: response.message,
          timestamp: Date.now()
        };
        
        if (session) {
          const messages = session.sessionData.messages || [];
          const updatedMessages = [...messages, newMessage, botResponse].slice(-20); // Keep last 20 messages
          await storage.updateChatSession(session.id, { messages: updatedMessages });
        } else {
          await storage.createChatSession({
            userId,
            sessionData: { messages: [newMessage, botResponse] }
          });
        }
      }
      
      res.json(response);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to process chat: " + error.message });
    }
  });

  app.get("/api/users/:userId/chat-history", async (req, res) => {
    try {
      const session = await storage.getChatSession(req.params.userId);
      res.json(session?.sessionData || { messages: [] });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch chat history: " + error.message });
    }
  });

  // Weather API
  app.get("/api/weather/:location", async (req, res) => {
    try {
      const weatherData = await getWeatherData(req.params.location);
      res.json(weatherData);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch weather: " + error.message });
    }
  });

  app.get("/api/road-conditions", async (req, res) => {
    try {
      const route = req.query.route as string;
      const conditions = await getRoadConditions(route);
      res.json(conditions);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch road conditions: " + error.message });
    }
  });

  app.get("/api/altitude-weather/:altitude", async (req, res) => {
    try {
      const altitude = parseInt(req.params.altitude);
      const altitudeWeather = await getAltitudeWeather(altitude);
      res.json(altitudeWeather);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch altitude weather: " + error.message });
    }
  });

  // Transport API
  app.post("/api/transport/options", async (req, res) => {
    try {
      const { from, to } = req.body;
      
      if (!from || !to) {
        return res.status(400).json({ message: "From and to locations are required" });
      }
      
      const options = await getTransportOptions(from, to);
      res.json(options);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch transport options: " + error.message });
    }
  });

  app.post("/api/transport/book", async (req, res) => {
    try {
      const bookingData = insertTransportBookingSchema.parse(req.body);
      const booking = await storage.createTransportBooking(bookingData);
      
      // Initiate external booking
      const result = await initiateBooking({
        fromLocation: bookingData.fromLocation,
        toLocation: bookingData.toLocation,
        bookingTime: bookingData.bookingTime,
        transportType: bookingData.provider
      });
      
      if (result.success && result.bookingId) {
        await storage.updateBookingStatus(booking.id, 'confirmed', result.bookingId);
      }
      
      res.json({ ...booking, ...result });
    } catch (error: any) {
      res.status(400).json({ message: "Failed to create booking: " + error.message });
    }
  });

  app.get("/api/transport/bookings/:bookingId/status", async (req, res) => {
    try {
      const status = await getBookingStatus(req.params.bookingId);
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch booking status: " + error.message });
    }
  });

  app.get("/api/users/:userId/bookings", async (req, res) => {
    try {
      const bookings = await storage.getUserTransportBookings(req.params.userId);
      res.json(bookings);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch bookings: " + error.message });
    }
  });

  // Permit information API
  app.get("/api/permits/:destination", async (req, res) => {
    try {
      const permitInfo = await getPermitInfo(req.params.destination);
      res.json(permitInfo);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch permit info: " + error.message });
    }
  });

  // Travel tips API
  app.get("/api/travel-tips/:attraction", async (req, res) => {
    try {
      const attraction = req.params.attraction;
      const weather = req.query.weather ? JSON.parse(req.query.weather as string) : undefined;
      const tips = await generateTravelTips(attraction, weather);
      res.json({ tips });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to generate travel tips: " + error.message });
    }
  });

  // User stats and leaderboard API
  app.get("/api/users/:userId/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.params.userId);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch user stats: " + error.message });
    }
  });

  app.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const leaderboard = await storage.getLeaderboard(limit);
      res.json(leaderboard);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch leaderboard: " + error.message });
    }
  });

  // User location update
  app.patch("/api/users/:userId/location", async (req, res) => {
    try {
      const { location } = req.body;
      if (!location || !location.lat || !location.lng) {
        return res.status(400).json({ message: "Valid location coordinates required" });
      }
      
      await storage.updateUserLocation(req.params.userId, location);
      res.json({ message: "Location updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to update location: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
