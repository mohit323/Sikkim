import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb, decimal } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email"),
  password: text("password").notNull(),
  currentLocation: jsonb("current_location").$type<{lat: number, lng: number, name?: string}>(),
  totalPoints: integer("total_points").default(0),
  level: integer("level").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attractions = pgTable("attractions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // monastery, lake, peak, cultural
  location: jsonb("location").$type<{lat: number, lng: number}>().notNull(),
  altitude: integer("altitude"),
  imageUrl: text("image_url"),
  visitCount: integer("visit_count").default(0),
  requiresPermit: boolean("requires_permit").default(false),
  openingHours: text("opening_hours"),
  difficulty: text("difficulty"), // easy, moderate, difficult
  badgePoints: integer("badge_points").default(10),
});

export const badges = pgTable("badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // explorer, eco, photo, community
  icon: text("icon").notNull(),
  requirements: jsonb("requirements").$type<{
    type: string,
    count: number,
    locations?: string[],
    conditions?: Record<string, any>
  }>().notNull(),
  points: integer("points").default(10),
  rarity: text("rarity").default("common"), // common, rare, epic, legendary
});

export const userBadges = pgTable("user_badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  badgeId: varchar("badge_id").notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").defaultNow(),
  progress: jsonb("progress").$type<Record<string, number>>().default({}),
});

export const checkIns = pgTable("check_ins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  attractionId: varchar("attraction_id").notNull().references(() => attractions.id),
  location: jsonb("location").$type<{lat: number, lng: number}>(),
  timestamp: timestamp("timestamp").defaultNow(),
  points: integer("points").default(10),
});

export const photos = pgTable("photos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  attractionId: varchar("attraction_id").references(() => attractions.id),
  url: text("url").notNull(),
  caption: text("caption"),
  location: jsonb("location").$type<{lat: number, lng: number, name?: string}>(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  likes: integer("likes").default(0),
});

export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  sessionData: jsonb("session_data").$type<{
    messages: Array<{role: string, content: string, timestamp: number}>,
    context?: Record<string, any>
  }>().default({ messages: [] }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transportBookings = pgTable("transport_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  provider: text("provider").notNull(), // ola, uber, local
  fromLocation: jsonb("from_location").$type<{lat: number, lng: number, name: string}>().notNull(),
  toLocation: jsonb("to_location").$type<{lat: number, lng: number, name: string}>().notNull(),
  bookingTime: timestamp("booking_time").notNull(),
  estimatedPrice: decimal("estimated_price"),
  status: text("status").default("pending"), // pending, confirmed, completed, cancelled
  externalBookingId: text("external_booking_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  badges: many(userBadges),
  checkIns: many(checkIns),
  photos: many(photos),
  chatSessions: many(chatSessions),
  transportBookings: many(transportBookings),
}));

export const badgesRelations = relations(badges, ({ many }) => ({
  userBadges: many(userBadges),
}));

export const attractionsRelations = relations(attractions, ({ many }) => ({
  checkIns: many(checkIns),
  photos: many(photos),
}));

export const userBadgesRelations = relations(userBadges, ({ one }) => ({
  user: one(users, { fields: [userBadges.userId], references: [users.id] }),
  badge: one(badges, { fields: [userBadges.badgeId], references: [badges.id] }),
}));

export const checkInsRelations = relations(checkIns, ({ one }) => ({
  user: one(users, { fields: [checkIns.userId], references: [users.id] }),
  attraction: one(attractions, { fields: [checkIns.attractionId], references: [attractions.id] }),
}));

export const photosRelations = relations(photos, ({ one }) => ({
  user: one(users, { fields: [photos.userId], references: [users.id] }),
  attraction: one(attractions, { fields: [photos.attractionId], references: [attractions.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
});

export const insertAttractionSchema = createInsertSchema(attractions).omit({
  id: true,
  visitCount: true,
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
});

export const insertCheckInSchema = createInsertSchema(checkIns).omit({
  id: true,
  timestamp: true,
  points: true,
});

export const insertPhotoSchema = createInsertSchema(photos).omit({
  id: true,
  uploadedAt: true,
  likes: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransportBookingSchema = createInsertSchema(transportBookings).omit({
  id: true,
  createdAt: true,
  status: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Attraction = typeof attractions.$inferSelect;
export type InsertAttraction = z.infer<typeof insertAttractionSchema>;

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;

export type UserBadge = typeof userBadges.$inferSelect;

export type CheckIn = typeof checkIns.$inferSelect;
export type InsertCheckIn = z.infer<typeof insertCheckInSchema>;

export type Photo = typeof photos.$inferSelect;
export type InsertPhoto = z.infer<typeof insertPhotoSchema>;

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;

export type TransportBooking = typeof transportBookings.$inferSelect;
export type InsertTransportBooking = z.infer<typeof insertTransportBookingSchema>;
