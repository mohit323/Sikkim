import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { MapPin, Car, Clock, ExternalLink, Leaf } from "lucide-react";
import { cn } from "@/lib/utils";

interface TransportOption {
  provider: string;
  type: string;
  estimatedPrice: number;
  estimatedTime: string;
  availability: string;
  features: string[];
  externalUrl?: string;
  ecoFriendly?: boolean;
}

const MOCK_USER_ID = "user_123";

export default function BookingWidget() {
  const [fromLocation, setFromLocation] = useState("");
  const [toLocation, setToLocation] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [searchResults, setSearchResults] = useState<TransportOption[]>([]);
  const [showResults, setShowResults] = useState(false);

  const searchMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/transport/options", {
        from: { lat: 27.3389, lng: 88.6065, name: fromLocation },
        to: { lat: 27.4000, lng: 88.7000, name: toLocation }
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSearchResults(data);
      setShowResults(true);
    }
  });

  const bookingMutation = useMutation({
    mutationFn: async (bookingData: any) => {
      const response = await apiRequest("POST", "/api/transport/book", {
        userId: MOCK_USER_ID,
        provider: bookingData.provider,
        fromLocation: { lat: 27.3389, lng: 88.6065, name: fromLocation },
        toLocation: { lat: 27.4000, lng: 88.7000, name: toLocation },
        bookingTime: new Date(`${date}T${time}`),
        estimatedPrice: bookingData.estimatedPrice
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.externalUrl) {
        window.open(data.externalUrl, '_blank');
      }
    }
  });

  const handleSearch = () => {
    if (!fromLocation || !toLocation) return;
    searchMutation.mutate();
  };

  const handleBook = (option: TransportOption) => {
    if (option.externalUrl) {
      window.open(option.externalUrl, '_blank');
    } else {
      bookingMutation.mutate({
        provider: option.provider,
        estimatedPrice: option.estimatedPrice
      });
    }
  };

  const getProviderColor = (provider: string) => {
    switch (provider.toLowerCase()) {
      case 'ola': return 'border-primary bg-primary';
      case 'uber': return 'border-secondary bg-secondary';
      case 'local shared taxi': return 'border-accent bg-accent';
      default: return 'border-muted bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Form */}
      <Card className="p-6">
        <h3 className="text-xl font-semibold mb-6">Book Your Ride</h3>
        
        <div className="space-y-4">
          {/* Location Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="from" className="block text-sm font-medium mb-2">From</Label>
              <div className="relative">
                <Input
                  id="from"
                  placeholder="Current location"
                  value={fromLocation}
                  onChange={(e) => setFromLocation(e.target.value)}
                  className="pr-10"
                  data-testid="input-from-location"
                />
                <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            
            <div>
              <Label htmlFor="to" className="block text-sm font-medium mb-2">To</Label>
              <div className="relative">
                <Input
                  id="to"
                  placeholder="Destination"
                  value={toLocation}
                  onChange={(e) => setToLocation(e.target.value)}
                  className="pr-10"
                  data-testid="input-to-location"
                />
                <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </div>
          
          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date" className="block text-sm font-medium mb-2">Date</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                data-testid="input-booking-date"
              />
            </div>
            <div>
              <Label htmlFor="time" className="block text-sm font-medium mb-2">Time</Label>
              <Input
                id="time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                data-testid="input-booking-time"
              />
            </div>
          </div>
          
          <Button 
            className="w-full" 
            onClick={handleSearch}
            disabled={!fromLocation || !toLocation || searchMutation.isPending}
            data-testid="button-search-transport"
          >
            {searchMutation.isPending ? (
              <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
            ) : (
              <Car className="mr-2 h-4 w-4" />
            )}
            {searchMutation.isPending ? "Searching..." : "Search Available Rides"}
          </Button>
        </div>
      </Card>

      {/* Search Results */}
      {showResults && (
        <div className="space-y-4">
          <h4 className="text-lg font-semibold">Available Options</h4>
          
          {searchResults.length === 0 ? (
            <Card className="p-6 text-center">
              <Car className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No transport options found for this route.</p>
            </Card>
          ) : (
            searchResults.map((option, index) => (
              <Card 
                key={index} 
                className={cn(
                  "p-6 border-l-4 transition-all duration-300 hover:shadow-lg transport-card",
                  getProviderColor(option.provider).replace('bg-', 'border-')
                )}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-muted rounded flex items-center justify-center">
                      <Car className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{option.provider}</h4>
                      <p className="text-sm text-muted-foreground flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        Available in {option.estimatedTime}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div 
                      className="font-bold text-lg"
                      data-testid={`text-price-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      ₹{option.estimatedPrice}
                    </div>
                    <div className="text-sm text-muted-foreground">Estimated</div>
                  </div>
                </div>
                
                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {option.features.map((feature, featureIndex) => (
                    <Badge key={featureIndex} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                  {option.ecoFriendly && (
                    <Badge variant="outline" className="text-xs border-secondary text-secondary">
                      <Leaf className="h-3 w-3 mr-1" />
                      Eco-friendly
                    </Badge>
                  )}
                </div>
                
                <div className="flex gap-3">
                  <Button 
                    className={cn("flex-1", getProviderColor(option.provider))}
                    onClick={() => handleBook(option)}
                    disabled={bookingMutation.isPending}
                    data-testid={`button-book-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {option.externalUrl && <ExternalLink className="h-4 w-4 mr-2" />}
                    {bookingMutation.isPending ? "Booking..." : "Book Now"}
                  </Button>
                  <Button variant="outline" data-testid={`button-details-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}>
                    Details
                  </Button>
                </div>
                
                {/* Eco Badge Progress */}
                {option.ecoFriendly && (
                  <div className="mt-3 p-2 bg-secondary/10 rounded-md">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-secondary font-medium flex items-center">
                        <Leaf className="h-3 w-3 mr-1" />
                        Eco Warrior Badge
                      </span>
                      <span className="text-xs text-muted-foreground">+5 points</span>
                    </div>
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}
