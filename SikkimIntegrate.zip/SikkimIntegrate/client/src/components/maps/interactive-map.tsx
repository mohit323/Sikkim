import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Layers } from "lucide-react";
import { cn } from "@/lib/utils";

interface InteractiveMapProps {
  center: { lat: number; lng: number };
  tracking?: boolean;
  mapType?: 'roadmap' | 'satellite';
  className?: string;
}

// Mock attractions data for demo
const mockAttractions = [
  { id: '1', name: 'Tsomgo Lake', lat: 27.3644, lng: 88.7511, category: 'lake' },
  { id: '2', name: 'Rumtek Monastery', lat: 27.2915, lng: 88.5460, category: 'monastery' },
  { id: '3', name: 'Nathu La Pass', lat: 27.3914, lng: 88.8403, category: 'pass' }
];

export default function InteractiveMap({ 
  center, 
  tracking = false, 
  mapType = 'roadmap',
  className 
}: InteractiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [userMarker, setUserMarker] = useState<any>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initialize Google Maps
  useEffect(() => {
    const initializeMap = () => {
      if (!mapRef.current || !window.google) return;

      const mapInstance = new window.google.maps.Map(mapRef.current, {
        center: center,
        zoom: 12,
        mapTypeId: mapType,
        styles: [
          {
            featureType: "poi",
            elementType: "labels",
            stylers: [{ visibility: "off" }]
          }
        ],
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
      });

      setMap(mapInstance);
      setIsLoaded(true);

      // Add attraction markers
      mockAttractions.forEach((attraction) => {
        const marker = new window.google.maps.Marker({
          position: { lat: attraction.lat, lng: attraction.lng },
          map: mapInstance,
          title: attraction.name,
          icon: {
            url: getMarkerIcon(attraction.category),
            scaledSize: new window.google.maps.Size(32, 32),
          },
        });

        const infoWindow = new window.google.maps.InfoWindow({
          content: `
            <div class="p-2">
              <h3 class="font-semibold">${attraction.name}</h3>
              <p class="text-sm text-gray-600">${attraction.category}</p>
            </div>
          `,
        });

        marker.addListener('click', () => {
          infoWindow.open(mapInstance, marker);
        });
      });
    };

    // Load Google Maps API if not already loaded
    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'demo_key'}&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onload = initializeMap;
      document.head.appendChild(script);
    } else {
      initializeMap();
    }
  }, [center, mapType]);

  // Handle tracking
  useEffect(() => {
    if (!map || !tracking) return;

    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const userPosition = { lat: latitude, lng: longitude };

          if (userMarker) {
            userMarker.setPosition(userPosition);
          } else {
            const marker = new window.google.maps.Marker({
              position: userPosition,
              map: map,
              title: "Your Location",
              icon: {
                url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="8" fill="#3B82F6" stroke="#ffffff" stroke-width="2"/>
                    <circle cx="12" cy="12" r="3" fill="#ffffff"/>
                  </svg>
                `),
                scaledSize: new window.google.maps.Size(24, 24),
              },
            });
            setUserMarker(marker);
          }

          map.panTo(userPosition);
        },
        (error) => {
          console.error("Geolocation error:", error);
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0,
        }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [map, tracking, userMarker]);

  const getMarkerIcon = (category: string) => {
    const colors = {
      lake: '#0EA5E9',
      monastery: '#F59E0B', 
      pass: '#8B5CF6',
      default: '#6B7280'
    };
    
    const color = colors[category as keyof typeof colors] || colors.default;
    
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 2C21.5228 2 26 6.47715 26 12C26 17.5228 21.5228 22 16 22C10.4772 22 6 17.5228 6 12C6 6.47715 10.4772 2 16 2Z" fill="${color}"/>
        <circle cx="16" cy="12" r="4" fill="white"/>
        <path d="M16 22L20 30H12L16 22Z" fill="${color}"/>
      </svg>
    `);
  };

  // Fallback map display when Google Maps is not available
  const FallbackMap = () => (
    <div className="w-full h-full bg-gradient-to-br from-primary/20 to-secondary/20 rounded-md flex items-center justify-center relative overflow-hidden">
      <img 
        src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
        alt="Sikkim mountain terrain" 
        className="w-full h-full object-cover"
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-primary/20" />
      
      {/* Location indicator */}
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white animate-pulse">
          <MapPin className="h-4 w-4" />
        </div>
      </div>
      
      {/* Info boxes */}
      <div className="absolute top-4 left-4 bg-card/90 backdrop-blur-sm p-2 rounded-md shadow-md">
        <div className="text-xs text-muted-foreground">Current Location</div>
        <div className="font-medium text-sm">Gangtok, Sikkim</div>
      </div>
      
      <div className="absolute bottom-4 right-4 bg-card/90 backdrop-blur-sm p-2 rounded-md shadow-md">
        <div className="text-xs text-muted-foreground">Distance to Tsomgo</div>
        <div className="font-medium text-sm">38 km</div>
      </div>

      {/* Loading indicator when not available */}
      {!window.google && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-white text-center">
            <div className="animate-spin w-8 h-8 border-4 border-white border-t-transparent rounded-full mx-auto mb-2" />
            <div className="text-sm">Loading interactive map...</div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className={cn("w-full h-96 rounded-md overflow-hidden map-container", className)}>
      {window.google && isLoaded ? (
        <div 
          ref={mapRef} 
          className="w-full h-full"
          data-testid="google-map-container"
        />
      ) : (
        <FallbackMap />
      )}
    </div>
  );
}
