import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Bot, Send, X, Phone, Cloud, Car, MapPin } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  suggestions?: string[];
  actions?: Array<{
    type: string;
    label: string;
    data?: any;
  }>;
}

const MOCK_USER_ID = "user_123";

export default function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "Namaste! I'm your Sikkim travel assistant. Ask me about attractions, weather, permits, or anything else!",
      timestamp: Date.now(),
      suggestions: ["How do I get a permit for Nathu La Pass?", "What's the weather like?", "Show me nearby attractions"]
    }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: chatHistory } = useQuery({
    queryKey: ["/api/users", MOCK_USER_ID, "chat-history"],
    enabled: isOpen,
  });

  const chatMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest("POST", "/api/chat", {
        message: messageText,
        userId: MOCK_USER_ID,
        context: {
          userLocation: { lat: 27.3389, lng: 88.6065, name: "Gangtok" }
        }
      });
      return response.json();
    },
    onSuccess: (data) => {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.message,
        timestamp: Date.now(),
        suggestions: data.suggestions,
        actions: data.actions
      }]);
    },
    onError: (error) => {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I'm experiencing some technical difficulties. Please try asking me something about Sikkim tourism!",
        timestamp: Date.now(),
        suggestions: ["Popular attractions", "Weather updates", "Transportation"]
      }]);
    }
  });

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  useEffect(() => {
    if (chatHistory?.messages) {
      setMessages(chatHistory.messages.map((msg: any) => ({
        ...msg,
        timestamp: msg.timestamp || Date.now()
      })));
    }
  }, [chatHistory]);

  const handleSendMessage = () => {
    if (!message.trim() || chatMutation.isPending) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: message,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(message);
    setMessage("");
  };

  const handleQuickAction = (action: string) => {
    const actionMessages = {
      weather: "What's the current weather in Gangtok?",
      permits: "How do I get permits for restricted areas?",
      transport: "Show me transportation options"
    };
    
    const actionMessage = actionMessages[action as keyof typeof actionMessages];
    if (actionMessage) {
      setMessage(actionMessage);
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setMessage(suggestion);
    handleSendMessage();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "w-14 h-14 rounded-full shadow-lg transition-all duration-300 floating-animation",
          isOpen ? "bg-secondary hover:bg-secondary/90" : "bg-primary hover:bg-primary/90"
        )}
        data-testid="button-chatbot-toggle"
      >
        {isOpen ? (
          <X className="h-6 w-6 text-white" />
        ) : (
          <Bot className="h-6 w-6 text-white" />
        )}
      </Button>

      {/* Chat Window */}
      {isOpen && (
        <Card className="absolute bottom-16 right-0 w-80 h-96 bg-card border border-border rounded-lg shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4" />
              </div>
              <div>
                <div className="font-medium text-sm">Sikkim AI Guide</div>
                <div className="text-xs opacity-90">Always here to help</div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
              data-testid="button-chatbot-close"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 space-y-3 h-64 overflow-y-auto bg-muted/20">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={cn(
                  "flex",
                  msg.role === 'user' ? "justify-end" : "items-start space-x-2",
                  "chat-message-enter"
                )}
              >
                {msg.role === 'assistant' && (
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center mt-1">
                    <Bot className="h-3 w-3 text-white" />
                  </div>
                )}
                
                <div
                  className={cn(
                    "max-w-xs p-3 rounded-lg shadow-sm",
                    msg.role === 'user'
                      ? "bg-primary text-primary-foreground"
                      : "bg-card"
                  )}
                >
                  <p className="text-sm">{msg.content}</p>
                  
                  {/* Action Buttons */}
                  {msg.actions && msg.actions.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {msg.actions.map((action, actionIndex) => (
                        <Button
                          key={actionIndex}
                          size="sm"
                          variant="outline"
                          className="w-full text-xs h-7"
                          onClick={() => {
                            if (action.type === "check_permit") {
                              // Handle permit checking
                              console.log("Check permit:", action.data);
                            }
                          }}
                          data-testid={`button-action-${action.type}`}
                        >
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  )}
                  
                  {/* Suggestions */}
                  {msg.suggestions && msg.suggestions.length > 0 && msg.role === 'assistant' && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {msg.suggestions.map((suggestion, suggestionIndex) => (
                        <Button
                          key={suggestionIndex}
                          size="sm"
                          variant="outline"
                          className="text-xs h-6 px-2"
                          onClick={() => handleSuggestionClick(suggestion)}
                          data-testid={`button-suggestion-${suggestionIndex}`}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            
            {chatMutation.isPending && (
              <div className="flex items-start space-x-2">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <Bot className="h-3 w-3 text-white" />
                </div>
                <div className="bg-card p-3 rounded-lg shadow-sm">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-border">
            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Ask about Sikkim..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 text-sm"
                disabled={chatMutation.isPending}
                data-testid="input-chat-message"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || chatMutation.isPending}
                size="sm"
                data-testid="button-send-message"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-7"
                onClick={() => handleQuickAction('weather')}
                data-testid="button-quick-weather"
              >
                <Cloud className="h-3 w-3 mr-1" />
                Weather
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-7"
                onClick={() => handleQuickAction('permits')}
                data-testid="button-quick-permits"
              >
                <MapPin className="h-3 w-3 mr-1" />
                Permits
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-7"
                onClick={() => handleQuickAction('transport')}
                data-testid="button-quick-transport"
              >
                <Car className="h-3 w-3 mr-1" />
                Transport
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
