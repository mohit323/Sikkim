import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Mountain, Menu, Globe, AlertTriangle, User } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Home" },
  { href: "/attractions", label: "Attractions" },
  { href: "/guides", label: "Guides" },
  { href: "/badges", label: "Badges" },
  { href: "/transport", label: "Transport" },
];

export default function Navigation() {
  const [location] = useLocation();
  const [currentLanguage, setCurrentLanguage] = useState("EN");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleLanguage = () => {
    setCurrentLanguage(currentLanguage === "EN" ? "हि" : "EN");
  };

  const showEmergencyModal = () => {
    const modal = document.getElementById('emergency-modal');
    modal?.classList.remove('hidden');
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <Mountain className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold text-primary">Sikkim Vibe Guide</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={cn(
                    "text-sm font-medium transition-colors",
                    location === item.href 
                      ? "text-primary bg-primary/10" 
                      : "text-foreground hover:text-primary"
                  )}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-4">
            {/* Translation Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="hidden sm:flex items-center text-muted-foreground hover:text-primary"
              data-testid="button-toggle-language"
            >
              <Globe className="h-4 w-4 mr-2" />
              <span>{currentLanguage}</span>
            </Button>

            {/* Emergency Button */}
            <Button
              size="sm"
              variant="destructive"
              onClick={showEmergencyModal}
              className="hidden sm:flex items-center"
              data-testid="button-emergency"
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Emergency
            </Button>

            {/* User Avatar */}
            <div className="flex items-center">
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                <User className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start",
                          location === item.href && "bg-primary/10 text-primary"
                        )}
                        onClick={() => setMobileMenuOpen(false)}
                        data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                      >
                        {item.label}
                      </Button>
                    </Link>
                  ))}
                  
                  <div className="border-t pt-4 space-y-2">
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={toggleLanguage}
                      data-testid="mobile-button-language"
                    >
                      <Globe className="h-4 w-4 mr-2" />
                      Language ({currentLanguage})
                    </Button>
                    
                    <Button
                      variant="destructive"
                      className="w-full justify-start"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        showEmergencyModal();
                      }}
                      data-testid="mobile-button-emergency"
                    >
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Emergency
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
