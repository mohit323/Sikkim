import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Camera, Upload, X, MapPin, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

interface PhotoUploadProps {
  attractionId?: string;
  onClose: () => void;
  onSuccess?: (photo: any) => void;
  isVisible: boolean;
}

const MOCK_USER_ID = "user_123";

export default function PhotoUpload({ 
  attractionId, 
  onClose, 
  onSuccess,
  isVisible 
}: PhotoUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [location, setLocation] = useState("");
  const [caption, setCaption] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadMutation = useMutation({
    mutationFn: async (photoData: FormData) => {
      const response = await apiRequest("POST", "/api/photos", photoData);
      return response.json();
    },
    onSuccess: (data) => {
      onSuccess?.(data);
      handleReset();
      onClose();
    }
  });

  const analyzePhotoMutation = useMutation({
    mutationFn: async (base64Image: string) => {
      const response = await apiRequest("POST", "/api/photos/analyze", {
        image: base64Image
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.location && data.confidence > 0.5) {
        setLocation(data.location);
      }
    }
  });

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    setSelectedFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreview(result);
      
      // Analyze photo for location
      const base64 = result.split(',')[1];
      if (base64) {
        analyzePhotoMutation.mutate(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleUpload = () => {
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('userId', MOCK_USER_ID);
    formData.append('caption', caption);
    formData.append('location', JSON.stringify({
      lat: 27.3389,
      lng: 88.6065,
      name: location || 'Sikkim'
    }));
    
    if (attractionId) {
      formData.append('attractionId', attractionId);
    }

    uploadMutation.mutate(formData);
  };

  const handleReset = () => {
    setSelectedFile(null);
    setPreview("");
    setLocation("");
    setCaption("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-60">
      <Card className="bg-card rounded-lg p-6 max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Upload Photo</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-close-photo-upload"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="space-y-4">
          {/* File Drop Zone */}
          {!selectedFile ? (
            <div
              className={cn(
                "border-2 border-dashed rounded-lg p-8 text-center transition-colors photo-drop-zone",
                dragOver && "drag-over border-primary bg-primary/5"
              )}
              onDrop={handleDrop}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
            >
              <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-3">
                Drop your photo here or click to browse
              </p>
              <Button 
                onClick={() => fileInputRef.current?.click()}
                data-testid="button-select-photo"
              >
                <Upload className="h-4 w-4 mr-2" />
                Select Photo
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileInput}
                className="hidden"
                data-testid="input-photo-file"
              />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Preview */}
              <div className="relative">
                <img 
                  src={preview} 
                  alt="Preview" 
                  className="w-full h-48 object-cover rounded-lg"
                />
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleReset}
                  className="absolute top-2 right-2"
                  data-testid="button-remove-photo"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Location Input */}
              <div>
                <Label htmlFor="location" className="flex items-center text-sm font-medium mb-2">
                  <MapPin className="h-4 w-4 mr-1" />
                  Location
                </Label>
                <Input
                  id="location"
                  placeholder="Where was this taken?"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  data-testid="input-photo-location"
                />
                {analyzePhotoMutation.isPending && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Analyzing photo location...
                  </p>
                )}
              </div>
              
              {/* Caption */}
              <div>
                <Label htmlFor="caption" className="block text-sm font-medium mb-2">
                  Caption
                </Label>
                <Textarea
                  id="caption"
                  placeholder="Share your experience..."
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="h-20 resize-none"
                  data-testid="textarea-photo-caption"
                />
              </div>
              
              {/* Badge Reward */}
              <div className="bg-accent/10 p-3 rounded-md">
                <div className="flex items-center space-x-2">
                  <Trophy className="h-4 w-4 text-accent" />
                  <span className="text-sm font-medium">Earn +15 points for Photo Master badge!</span>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button 
                  className="flex-1"
                  onClick={handleUpload}
                  disabled={uploadMutation.isPending || !location}
                  data-testid="button-upload-photo"
                >
                  {uploadMutation.isPending ? (
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                  ) : (
                    <Upload className="h-4 w-4 mr-2" />
                  )}
                  {uploadMutation.isPending ? "Uploading..." : "Upload & Share"}
                </Button>
                <Button 
                  variant="outline"
                  onClick={onClose}
                  data-testid="button-cancel-upload"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
