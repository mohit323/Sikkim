import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertTriangle, Phone, MapPin, X, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

export default function EmergencyModal() {
  const [isVisible, setIsVisible] = useState(false);

  // Listen for emergency modal trigger
  useState(() => {
    const handleShow = () => setIsVisible(true);
    const modal = document.getElementById('emergency-modal');
    if (modal) {
      // Remove existing event listeners
      modal.removeEventListener('show', handleShow);
      modal.addEventListener('show', handleShow);
    }
  });

  const emergencyContacts = [
    { 
      name: "Police Emergency", 
      number: "100", 
      icon: Shield,
      description: "Immediate police assistance"
    },
    { 
      name: "Medical Emergency", 
      number: "108", 
      icon: Phone,
      description: "Ambulance and medical help"
    },
    { 
      name: "Tourism Helpline", 
      number: "1363", 
      icon: Phone,
      description: "Tourist assistance and information"
    },
    { 
      name: "Disaster Management", 
      number: "1070", 
      icon: AlertTriangle,
      description: "Natural disaster and rescue"
    }
  ];

  const handleCall = (number: string) => {
    // In a real app, this would initiate a phone call
    window.open(`tel:${number}`);
  };

  const handleShareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const locationUrl = `https://maps.google.com?q=${latitude},${longitude}`;
          
          // Copy to clipboard
          navigator.clipboard.writeText(locationUrl).then(() => {
            alert("Location copied to clipboard!");
          });
          
          // In a real app, this would send location to emergency services
          console.log("Location shared:", { latitude, longitude });
        },
        (error) => {
          console.error("Location error:", error);
          alert("Unable to get your location. Please enable location services.");
        }
      );
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div 
      id="emergency-modal"
      className="fixed inset-0 bg-red-900/90 backdrop-blur-sm flex items-center justify-center z-60 emergency-overlay"
      data-testid="emergency-modal"
    >
      <Card className="bg-card rounded-lg p-6 max-w-md w-full mx-4 shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-destructive rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="h-8 w-8 text-destructive-foreground" />
          </div>
          <h3 className="text-xl font-bold text-destructive">Emergency Assistance</h3>
          <p className="text-muted-foreground mt-2">Get immediate help when you need it most</p>
        </div>
        
        <div className="space-y-3">
          {emergencyContacts.map((contact) => {
            const IconComponent = contact.icon;
            return (
              <Button
                key={contact.number}
                onClick={() => handleCall(contact.number)}
                className="w-full bg-destructive text-destructive-foreground py-3 px-4 rounded-md font-semibold hover:bg-destructive/90 transition-colors flex items-center justify-start"
                data-testid={`button-call-${contact.number}`}
              >
                <IconComponent className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <div className="font-semibold">{contact.name}: {contact.number}</div>
                  <div className="text-xs opacity-90">{contact.description}</div>
                </div>
              </Button>
            );
          })}
          
          <Button
            onClick={handleShareLocation}
            className="w-full bg-accent text-accent-foreground py-3 px-4 rounded-md font-semibold hover:bg-accent/90 transition-colors flex items-center justify-center"
            data-testid="button-share-location"
          >
            <MapPin className="h-5 w-5 mr-3" />
            Share My Location
          </Button>
        </div>
        
        <div className="mt-6 p-3 bg-muted/50 rounded-md">
          <p className="text-xs text-muted-foreground text-center">
            Your location will be automatically shared with emergency services when you make a call.
            For immediate assistance, call the appropriate emergency number above.
          </p>
        </div>
        
        <Button
          onClick={handleClose}
          variant="outline"
          className="w-full mt-4 py-2 px-4 rounded-md font-medium hover:bg-muted transition-colors"
          data-testid="button-close-emergency"
        >
          <X className="h-4 w-4 mr-2" />
          Close
        </Button>
      </Card>
    </div>
  );
}
