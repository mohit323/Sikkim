import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Trophy, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface BadgeProgressProps {
  badge: {
    id: string;
    name: string;
    description: string;
    category: string;
    requirements: {
      type: string;
      count: number;
    };
    points: number;
    rarity: string;
  };
  progress: {
    current: number;
    total: number;
    percentage: number;
  };
  isEarned?: boolean;
  className?: string;
}

const rarityColors = {
  common: "border-gray-300 text-gray-600",
  rare: "border-blue-400 text-blue-600",
  epic: "border-purple-500 text-purple-600",
  legendary: "border-yellow-400 text-yellow-600"
};

export default function BadgeProgress({ 
  badge, 
  progress, 
  isEarned = false, 
  className 
}: BadgeProgressProps) {
  return (
    <Card className={cn(
      "p-4 transition-all duration-300",
      isEarned ? "bg-accent/10 border-accent" : "border-border",
      className
    )}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center relative",
            isEarned ? "bg-accent" : "bg-muted"
          )}>
            <Trophy className={cn(
              "h-6 w-6",
              isEarned ? "text-white" : "text-muted-foreground"
            )} />
            {isEarned && (
              <div className="absolute -top-1 -right-1">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
              </div>
            )}
          </div>
          
          <div>
            <h4 className={cn(
              "font-semibold",
              !isEarned && "text-muted-foreground"
            )}>
              {badge.name}
            </h4>
            <p className={cn(
              "text-sm",
              isEarned ? "text-foreground" : "text-muted-foreground"
            )}>
              {badge.description}
            </p>
          </div>
        </div>
        
        <div className="text-right">
          <div className={cn(
            "text-xs px-2 py-1 rounded-full border",
            rarityColors[badge.rarity as keyof typeof rarityColors]
          )}>
            {badge.rarity}
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      {!isEarned && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Progress</span>
            <span 
              className="font-medium"
              data-testid={`text-badge-progress-${badge.id}`}
            >
              {progress.current}/{progress.total}
            </span>
          </div>
          <Progress 
            value={progress.percentage} 
            className="h-2 badge-progress-fill"
          />
          <div className="text-xs text-muted-foreground">
            {badge.requirements.type === 'visit_count' && `Visit ${badge.requirements.count - progress.current} more locations`}
            {badge.requirements.type === 'photo_upload' && `Upload ${badge.requirements.count - progress.current} more photos`}
            {badge.requirements.type === 'checkin_count' && `${badge.requirements.count - progress.current} more check-ins needed`}
          </div>
        </div>
      )}

      {/* Points */}
      <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
        <span className="text-sm text-muted-foreground">Points</span>
        <span className={cn(
          "font-semibold",
          isEarned ? "text-accent" : "text-muted-foreground"
        )}>
          {badge.points} pts
        </span>
      </div>

      {/* Earned Badge Indicator */}
      {isEarned && (
        <div className="mt-2 p-2 bg-accent/20 rounded-md">
          <div className="flex items-center space-x-2">
            <Trophy className="h-4 w-4 text-accent" />
            <span className="text-sm font-medium text-accent">Badge Earned!</span>
          </div>
        </div>
      )}
    </Card>
  );
}
