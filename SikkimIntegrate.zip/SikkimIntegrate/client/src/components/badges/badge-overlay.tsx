import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { X, Trophy, Mountain, Camera } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

const MOCK_USER_ID = "user_123";

export default function BadgeOverlay() {
  const [isVisible, setIsVisible] = useState(true);

  const { data: userBadges } = useQuery({
    queryKey: ["/api/users", MOCK_USER_ID, "badges"],
  });

  const { data: userStats } = useQuery({
    queryKey: ["/api/users", MOCK_USER_ID, "stats"],
  });

  // Calculate current progress for active badges
  const currentBadgeProgress = {
    mountainExplorer: {
      current: 2,
      total: 3,
      percentage: 66.6
    },
    photoMaster: {
      current: 8, 
      total: 10,
      percentage: 80
    }
  };

  const recentBadge = userBadges?.[0];

  if (!isVisible) return null;

  return (
    <div className="fixed top-20 right-4 z-40 hidden lg:block">
      <Card className="bg-card/95 backdrop-blur-sm border border-border rounded-lg p-4 shadow-lg max-w-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-sm">Progress Tracker</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsVisible(false)}
            className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
            data-testid="button-close-badge-overlay"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>

        {/* Current Badge Progress */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <Mountain className="text-white text-xs" />
              </div>
              <span className="text-sm">Mountain Explorer</span>
            </div>
            <span 
              className="text-xs text-muted-foreground"
              data-testid="text-mountain-explorer-progress"
            >
              {currentBadgeProgress.mountainExplorer.current}/{currentBadgeProgress.mountainExplorer.total}
            </span>
          </div>

          <Progress 
            value={currentBadgeProgress.mountainExplorer.percentage} 
            className="h-2 badge-progress-fill"
          />

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <Camera className="text-white text-xs" />
              </div>
              <span className="text-sm">Photo Master</span>
            </div>
            <span 
              className="text-xs text-muted-foreground"
              data-testid="text-photo-master-progress"
            >
              {currentBadgeProgress.photoMaster.current}/{currentBadgeProgress.photoMaster.total}
            </span>
          </div>

          <Progress 
            value={currentBadgeProgress.photoMaster.percentage} 
            className="h-2 badge-progress-fill"
          />
        </div>

        {/* Recent Achievement */}
        {recentBadge && (
          <div className="mt-4 p-3 bg-accent/10 rounded-md border-l-4 border-accent">
            <div className="flex items-center space-x-2">
              <Trophy className="h-4 w-4 text-accent" />
              <span className="text-sm font-medium">New Badge Earned!</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {recentBadge.badge.name} - {recentBadge.badge.description}
            </p>
            <div className="text-xs text-accent font-medium mt-1">
              +{recentBadge.badge.points} points earned
            </div>
          </div>
        )}

        {/* Current Points */}
        {userStats && (
          <div className="mt-4 pt-3 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Points</span>
              <span 
                className="font-semibold text-primary"
                data-testid="text-total-points-overlay"
              >
                {userStats.totalPoints}
              </span>
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="mt-3">
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full text-xs"
            data-testid="button-view-all-badges"
          >
            View All Badges
          </Button>
        </div>
      </Card>
    </div>
  );
}
