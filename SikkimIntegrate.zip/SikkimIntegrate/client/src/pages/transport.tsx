import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { MapPin, Car, Bus, Bike, Users, Clock, Leaf } from "lucide-react";
import BookingWidget from "@/components/transport/booking-widget";
import { cn } from "@/lib/utils";

const transportTypes = [
  { id: 'cab', label: 'Cab/Taxi', icon: Car, color: 'text-primary', bgColor: 'bg-primary' },
  { id: 'bus', label: 'Shared Bus', icon: Bus, color: 'text-secondary', bgColor: 'bg-secondary' },
  { id: 'bike', label: 'Bike Rental', icon: Bike, color: 'text-accent', bgColor: 'bg-accent' },
  { id: 'trek', label: 'Trekking Guide', icon: Users, color: 'text-purple-500', bgColor: 'bg-purple-500' },
];

const mockTransportOptions = [
  {
    provider: "Ola",
    type: "cab",
    estimatedPrice: 450,
    estimatedTime: "3 min",
    availability: "available",
    features: ["GPS tracking", "24/7 support", "Cashless payment"],
    color: "border-primary",
    bgColor: "bg-primary"
  },
  {
    provider: "Uber", 
    type: "cab",
    estimatedPrice: 425,
    estimatedTime: "5 min",
    availability: "available",
    features: ["Real-time tracking", "In-app payment", "Driver ratings"],
    color: "border-secondary",
    bgColor: "bg-secondary"
  },
  {
    provider: "Local Shared Taxi",
    type: "shared",
    estimatedPrice: 180,
    estimatedTime: "10 min",
    availability: "available",
    features: ["Eco-friendly", "Local experience", "Fixed routes"],
    color: "border-accent",
    bgColor: "bg-accent",
    badgeInfo: { name: "Eco Warrior Badge", points: 5 }
  }
];

export default function Transport() {
  const [selectedTransport, setSelectedTransport] = useState('cab');
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const handleSearch = () => {
    console.log("Searching rides...", { fromLocation, toLocation, date, time, selectedTransport });
  };

  const handleBook = (provider: string) => {
    console.log("Booking with:", provider);
  };

  return (
    <div className="min-h-screen pt-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Smart Transportation
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Integrated booking for cabs, buses, and local transport. Real-time availability and competitive pricing.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Booking Widget */}
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-6">Book Your Ride</h3>
            
            <div className="space-y-4">
              {/* Location Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="from" className="block text-sm font-medium text-foreground mb-2">From</Label>
                  <div className="relative">
                    <Input
                      id="from"
                      type="text"
                      placeholder="Current location"
                      value={fromLocation}
                      onChange={(e) => setFromLocation(e.target.value)}
                      className="pr-10"
                      data-testid="input-from-location"
                    />
                    <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="to" className="block text-sm font-medium text-foreground mb-2">To</Label>
                  <div className="relative">
                    <Input
                      id="to"
                      type="text"
                      placeholder="Destination"
                      value={toLocation}
                      onChange={(e) => setToLocation(e.target.value)}
                      className="pr-10"
                      data-testid="input-to-location"
                    />
                    <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </div>
              
              {/* Date and Time */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date" className="block text-sm font-medium text-foreground mb-2">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    data-testid="input-date"
                  />
                </div>
                <div>
                  <Label htmlFor="time" className="block text-sm font-medium text-foreground mb-2">Time</Label>
                  <Input
                    id="time"
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    data-testid="input-time"
                  />
                </div>
              </div>
              
              {/* Transport Type Selection */}
              <div>
                <Label className="block text-sm font-medium text-foreground mb-3">Transport Type</Label>
                <div className="grid grid-cols-2 gap-3">
                  {transportTypes.map((type) => {
                    const IconComponent = type.icon;
                    return (
                      <Button
                        key={type.id}
                        variant={selectedTransport === type.id ? "default" : "outline"}
                        className={cn(
                          "p-3 h-auto flex-col space-y-2 transition-colors",
                          selectedTransport === type.id && type.bgColor
                        )}
                        onClick={() => setSelectedTransport(type.id)}
                        data-testid={`button-transport-${type.id}`}
                      >
                        <IconComponent className="h-6 w-6" />
                        <span className="text-sm font-medium">{type.label}</span>
                      </Button>
                    );
                  })}
                </div>
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleSearch}
                disabled={!fromLocation || !toLocation}
                data-testid="button-search-rides"
              >
                <Car className="mr-2 h-4 w-4" />
                Search Available Rides
              </Button>
            </div>
          </Card>
          
          {/* Transport Options */}
          <div className="space-y-6">
            {mockTransportOptions.map((option, index) => (
              <Card key={index} className={cn("p-6 border-l-4", option.color)}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-muted rounded flex items-center justify-center">
                      <Car className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{option.provider}</h4>
                      <p className="text-sm text-muted-foreground flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        Available in {option.estimatedTime}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg" data-testid={`text-price-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}>
                      ₹{option.estimatedPrice}
                    </div>
                    <div className="text-sm text-muted-foreground">Estimated</div>
                  </div>
                </div>
                
                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {option.features.map((feature, featureIndex) => (
                    <Badge key={featureIndex} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex gap-3">
                  <Button 
                    className={cn("flex-1", option.bgColor)}
                    onClick={() => handleBook(option.provider)}
                    data-testid={`button-book-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    Book Now
                  </Button>
                  <Button 
                    variant="outline" 
                    data-testid={`button-details-${option.provider.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    Details
                  </Button>
                </div>
                
                {/* Badge Progress */}
                {option.badgeInfo && (
                  <div className="mt-3 p-2 bg-secondary/10 rounded-md">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-secondary font-medium flex items-center">
                        <Leaf className="h-3 w-3 mr-1" />
                        {option.badgeInfo.name}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        +{option.badgeInfo.points} points
                      </span>
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>
        
        {/* Recent Bookings */}
        <Card className="p-6 mt-8">
          <h3 className="text-lg font-semibold mb-4">Recent Bookings</h3>
          <div className="text-center py-8 text-muted-foreground">
            <Car className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <p>No recent bookings found.</p>
            <p className="text-sm">Your transport history will appear here.</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
