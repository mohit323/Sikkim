import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Camera, MapPin, Mountain, Users, Trophy, Compass } from "lucide-react";
import { Link } from "wouter";
import { useWeather } from "@/hooks/use-weather";
import type { Attraction, User } from "@/../../shared/schema";

export default function Home() {
  const { data: attractions } = useQuery<Attraction[]>({
    queryKey: ["/api/attractions"],
  });

  const { data: leaderboard } = useQuery<User[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: weather } = useWeather("Gangtok");

  const featuredAttractions = attractions?.slice(0, 3) || [];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-secondary/80" />
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl sm:text-6xl font-bold text-white mb-6 floating-animation">
            Discover the Magic of <span className="text-accent">Sikkim</span>
          </h1>
          <p className="text-xl sm:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
            Your AI-powered companion for exploring the Himalayas. Earn badges, discover hidden gems, and create unforgettable memories in the Land of Thunderbolt.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/attractions">
              <Button size="lg" className="text-lg font-semibold hover:scale-105 transition-transform" data-testid="button-start-journey">
                <Compass className="mr-2 h-5 w-5" />
                Start Your Journey
              </Button>
            </Link>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg font-semibold bg-white/20 border-white/30 text-white hover:bg-white/30"
              data-testid="button-open-chatbot"
            >
              <Mountain className="mr-2 h-5 w-5" />
              Ask AI Guide
            </Button>
          </div>
          
          {/* Live Stats */}
          <div className="mt-12 grid grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-accent" data-testid="text-attractions-count">
                {attractions?.length || 0}+
              </div>
              <div className="text-white/80">Attractions</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent" data-testid="text-badges-count">50+</div>
              <div className="text-white/80">Badges Available</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent" data-testid="text-users-count">
                {leaderboard?.length || 0}K+
              </div>
              <div className="text-white/80">Active Explorers</div>
            </div>
          </div>
        </div>
        
        {/* Weather Widget */}
        {weather && (
          <div className="absolute bottom-6 right-6 bg-card/80 backdrop-blur-sm rounded-lg p-4 hidden sm:block border border-border/50">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">☀️</div>
              <div>
                <div className="text-sm text-muted-foreground">Gangtok</div>
                <div className="font-semibold" data-testid="text-weather-temp">
                  {weather.temperature}°C
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Featured Attractions */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Featured Attractions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover the most popular destinations in Sikkim
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredAttractions.map((attraction: any) => (
              <Card key={attraction.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <div className="h-48 bg-muted relative">
                  {attraction.imageUrl && (
                    <img 
                      src={attraction.imageUrl} 
                      alt={attraction.name}
                      className="w-full h-full object-cover"
                    />
                  )}
                  <div className="absolute top-4 right-4">
                    <span className="bg-secondary/90 text-secondary-foreground px-2 py-1 rounded-full text-xs">
                      {attraction.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{attraction.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    {attraction.description?.substring(0, 100)}...
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      {attraction.altitude && (
                        <span><Mountain className="h-4 w-4 inline mr-1" />{attraction.altitude} ft</span>
                      )}
                    </div>
                    <div className="text-accent font-medium">
                      {attraction.visitCount || 0} visits
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link href="/attractions">
              <Button variant="outline" size="lg" data-testid="button-view-all-attractions">
                View All Attractions
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Start Exploring
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need for your Sikkim adventure
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/attractions">
              <Card className="p-6 text-center hover:shadow-lg transition-shadow cursor-pointer">
                <MapPin className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Explore Places</h3>
                <p className="text-sm text-muted-foreground">
                  Discover monasteries, lakes, and peaks
                </p>
              </Card>
            </Link>
            
            <Link href="/badges">
              <Card className="p-6 text-center hover:shadow-lg transition-shadow cursor-pointer">
                <Trophy className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Earn Badges</h3>
                <p className="text-sm text-muted-foreground">
                  Complete challenges and unlock achievements
                </p>
              </Card>
            </Link>
            
            <Link href="/guides">
              <Card className="p-6 text-center hover:shadow-lg transition-shadow cursor-pointer">
                <Compass className="h-12 w-12 text-secondary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Smart Guides</h3>
                <p className="text-sm text-muted-foreground">
                  AI-powered navigation and local insights
                </p>
              </Card>
            </Link>
            
            <Link href="/transport">
              <Card className="p-6 text-center hover:shadow-lg transition-shadow cursor-pointer">
                <Users className="h-12 w-12 text-purple-500 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Book Transport</h3>
                <p className="text-sm text-muted-foreground">
                  Easy booking for cabs, buses, and rides
                </p>
              </Card>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
