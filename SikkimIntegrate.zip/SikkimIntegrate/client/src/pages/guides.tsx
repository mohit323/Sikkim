import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Phone, Bed, Car, AlertTriangle } from "lucide-react";
import InteractiveMap from "@/components/maps/interactive-map";
import { useWeather } from "@/hooks/use-weather";
import { useLocation } from "@/hooks/use-location";

export default function Guides() {
  const [trackingEnabled, setTrackingEnabled] = useState(false);
  const [mapView, setMapView] = useState<'roadmap' | 'satellite'>('roadmap');
  
  const { data: weather } = useWeather("Gangtok");
  const { location, requestLocation } = useLocation();

  const handleEnableTracking = () => {
    if (!location) {
      requestLocation();
    }
    setTrackingEnabled(!trackingEnabled);
  };

  const nearbyAttractions = [
    {
      id: "enchey-monastery",
      name: "Enchey Monastery",
      distance: "2.5 km",
      icon: "🏛️",
      category: "monastery"
    },
    {
      id: "tashi-viewpoint",
      name: "Tashi Viewpoint",
      distance: "8 km", 
      icon: "⛰️",
      category: "viewpoint"
    },
    {
      id: "flower-exhibition-centre",
      name: "Flower Exhibition Centre",
      distance: "3.2 km",
      icon: "🌸",
      category: "garden"
    }
  ];

  return (
    <div className="min-h-screen pt-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Interactive Travel Guides
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Real-time navigation with Google Maps integration, weather updates, and local insights.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Container */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Live Map Guide</h3>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={trackingEnabled ? "default" : "outline"}
                    size="sm"
                    onClick={handleEnableTracking}
                    data-testid="button-enable-tracking"
                  >
                    <MapPin className="h-4 w-4 mr-1" />
                    {trackingEnabled ? "Tracking" : "Track Me"}
                  </Button>
                  <Button
                    variant={mapView === 'satellite' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setMapView(mapView === 'satellite' ? 'roadmap' : 'satellite')}
                    data-testid="button-toggle-satellite"
                  >
                    <Navigation className="h-4 w-4 mr-1" />
                    {mapView === 'satellite' ? 'Road' : 'Satellite'}
                  </Button>
                </div>
              </div>
              
              <InteractiveMap 
                center={location || { lat: 27.3389, lng: 88.6065 }}
                tracking={trackingEnabled}
                mapType={mapView}
              />
              
              {/* Route Information */}
              <div className="mt-4 p-4 bg-muted/50 rounded-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Estimated Time:</span>
                      <span className="font-medium ml-1" data-testid="text-route-duration">1h 45m</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Road Conditions:</span>
                      <span className="text-secondary font-medium ml-1" data-testid="text-road-conditions">Good</span>
                    </div>
                  </div>
                  <Button data-testid="button-start-navigation">
                    Start Navigation
                  </Button>
                </div>
              </div>
            </Card>
          </div>
          
          {/* Guide Panel */}
          <div className="space-y-6">
            {/* Current Weather */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Current Conditions</h3>
              <div className="space-y-4">
                {weather ? (
                  <>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">☀️</div>
                        <div>
                          <div className="font-medium" data-testid="text-weather-location">
                            {weather.location}
                          </div>
                          <div className="text-sm text-muted-foreground" data-testid="text-weather-condition">
                            {weather.condition}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold" data-testid="text-weather-temperature">
                          {weather.temperature}°C
                        </div>
                        <div className="text-sm text-muted-foreground" data-testid="text-weather-humidity">
                          Humidity: {weather.humidity}%
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-border pt-3">
                      <div className="text-sm text-muted-foreground mb-2">Road Conditions</div>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-secondary rounded-full"></div>
                        <span className="text-sm">Clear roads to major attractions</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">Loading weather...</p>
                  </div>
                )}
              </div>
            </Card>
            
            {/* Nearby Points of Interest */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Nearby Attractions</h3>
              <div className="space-y-3">
                {nearbyAttractions.map((attraction) => (
                  <div 
                    key={attraction.id}
                    className="flex items-center justify-between p-3 bg-muted/30 rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                    data-testid={`attraction-${attraction.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-sm">
                        {attraction.icon}
                      </div>
                      <div>
                        <div className="font-medium text-sm">{attraction.name}</div>
                        <div className="text-xs text-muted-foreground">{attraction.distance} away</div>
                      </div>
                    </div>
                    <Button size="sm" variant="ghost" data-testid={`button-directions-${attraction.id}`}>
                      <Navigation className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
            
            {/* Quick Actions */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button className="w-full justify-center" data-testid="button-book-transport">
                  <Car className="mr-2 h-4 w-4" />
                  Book Transport
                </Button>
                <Button variant="secondary" className="w-full justify-center" data-testid="button-find-accommodation">
                  <Bed className="mr-2 h-4 w-4" />
                  Find Stay
                </Button>
                <Button variant="destructive" className="w-full justify-center" data-testid="button-emergency-help">
                  <Phone className="mr-2 h-4 w-4" />
                  Emergency Help
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
