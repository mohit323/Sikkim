import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Camera, Map, Shield, Clock, Mountain } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Attraction } from "@/../../shared/schema";

const categories = [
  { id: "all", label: "All", icon: "🏔️" },
  { id: "monasteries", label: "Monasteries", icon: "🏛️" },
  { id: "lakes", label: "Lakes", icon: "🏞️" },
  { id: "peaks", label: "Peaks", icon: "⛰️" },
  { id: "cultural", label: "Cultural Sites", icon: "🎭" },
];

export default function Attractions() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  
  const { data: attractions, isLoading } = useQuery<Attraction[]>({
    queryKey: ["/api/attractions", selectedCategory !== "all" ? `?category=${selectedCategory}` : ""],
  });

  const filteredAttractions = selectedCategory === "all" 
    ? attractions 
    : attractions?.filter((a: Attraction) => a.category === selectedCategory);

  const handleCheckIn = async (attractionId: string) => {
    // TODO: Implement check-in functionality
    console.log("Check in at:", attractionId);
  };

  const handlePhotoUpload = (attractionId: string) => {
    // TODO: Open photo upload modal
    console.log("Upload photo for:", attractionId);
  };

  const handleViewMap = (attractionId: string) => {
    // TODO: Open map view
    console.log("View map for:", attractionId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Explore Sikkim's Treasures
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover monasteries, lakes, peaks, and hidden gems. Check in at locations to earn badges and unlock exclusive content.
          </p>
        </div>
        
        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 justify-center mb-8">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className={cn(
                "transition-colors",
                selectedCategory === category.id && "bg-primary text-primary-foreground"
              )}
              data-testid={`button-filter-${category.id}`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
            </Button>
          ))}
        </div>
        
        {/* Attractions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredAttractions?.map((attraction: any) => (
            <Card 
              key={attraction.id} 
              className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              data-testid={`card-attraction-${attraction.id}`}
            >
              <div className="h-48 bg-muted relative">
                {attraction.imageUrl ? (
                  <img 
                    src={attraction.imageUrl} 
                    alt={attraction.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20">
                    <Mountain className="h-16 w-16 text-muted-foreground" />
                  </div>
                )}
                
                <div className="absolute top-4 right-4 flex gap-2">
                  <Badge variant="secondary" className="bg-secondary/90 text-secondary-foreground">
                    {attraction.category}
                  </Badge>
                  {attraction.requiresPermit && (
                    <Badge variant="destructive" className="bg-accent/90 text-accent-foreground">
                      <Shield className="h-3 w-3 mr-1" />
                      Permit
                    </Badge>
                  )}
                </div>
                
                {/* Live indicator */}
                <div className="absolute top-4 left-4">
                  <div className="w-3 h-3 bg-secondary rounded-full animate-pulse" />
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold">{attraction.name}</h3>
                </div>
                
                <p className="text-muted-foreground text-sm mb-4">
                  {attraction.description?.substring(0, 100)}
                  {attraction.description?.length > 100 && "..."}
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    {attraction.altitude && (
                      <span>
                        <Mountain className="h-4 w-4 inline mr-1" />
                        {attraction.altitude.toLocaleString()} ft
                      </span>
                    )}
                    {attraction.openingHours && (
                      <span>
                        <Clock className="h-4 w-4 inline mr-1" />
                        {attraction.openingHours}
                      </span>
                    )}
                  </div>
                  <div className="text-accent font-medium" data-testid={`text-visit-count-${attraction.id}`}>
                    {(attraction.visitCount || 0).toLocaleString()} visits
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button 
                    className="flex-1" 
                    onClick={() => handleCheckIn(attraction.id)}
                    data-testid={`button-checkin-${attraction.id}`}
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    Check In
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => handlePhotoUpload(attraction.id)}
                    data-testid={`button-photo-${attraction.id}`}
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => handleViewMap(attraction.id)}
                    data-testid={`button-map-${attraction.id}`}
                  >
                    <Map className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Badge Indicator */}
                <div className="mt-3 p-2 bg-accent/10 rounded-md">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-accent font-medium">
                      {attraction.category === 'monasteries' ? 'Cultural Explorer Badge' :
                       attraction.category === 'peaks' ? 'Mountain Explorer Badge' :
                       attraction.category === 'lakes' ? 'Nature Lover Badge' :
                       'Explorer Badge'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      +{attraction.badgePoints || 10} points
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        {(!filteredAttractions || filteredAttractions.length === 0) && (
          <div className="text-center py-12">
            <Mountain className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No attractions found</h3>
            <p className="text-muted-foreground">
              {selectedCategory === "all" 
                ? "No attractions available at the moment."
                : `No ${selectedCategory} found. Try a different category.`
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
