import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Trophy, Mountain, Leaf, Camera, Users, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Badge as BadgeType, UserBadge, User } from "@/../../shared/schema";

// Define UserStats type based on API response
type UserStats = {
  totalCheckIns: number;
  totalPhotos: number;
  totalPoints: number;
  totalBadges: number;
};

// Mock user ID for demo
const MOCK_USER_ID = "user_123";

const badgeCategories = [
  { id: "explorer", label: "Explorer", icon: Mountain, color: "text-primary", bgColor: "bg-primary" },
  { id: "eco", label: "Eco Warrior", icon: Leaf, color: "text-secondary", bgColor: "bg-secondary" },
  { id: "photo", label: "Photographer", icon: Camera, color: "text-accent", bgColor: "bg-accent" },
  { id: "community", label: "Community", icon: Users, color: "text-purple-500", bgColor: "bg-purple-500" },
];

const rarityColors = {
  common: "border-gray-300",
  rare: "border-blue-400",
  epic: "border-purple-500", 
  legendary: "border-yellow-400"
};

export default function Badges() {
  const { data: allBadges, isLoading: badgesLoading } = useQuery<BadgeType[]>({
    queryKey: ["/api/badges"],
  });

  const { data: userBadges, isLoading: userBadgesLoading } = useQuery<UserBadge[]>({
    queryKey: ["/api/users", MOCK_USER_ID, "badges"],
  });

  const { data: leaderboard } = useQuery<User[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: userStats } = useQuery<UserStats>({
    queryKey: ["/api/users", MOCK_USER_ID, "stats"],
  });

  const earnedBadgeIds = new Set(userBadges?.map((ub: UserBadge) => ub.badgeId) || []);
  
  const badgesByCategory = allBadges?.reduce((acc: Record<string, BadgeType[]>, badge: BadgeType) => {
    if (!acc[badge.category]) acc[badge.category] = [];
    acc[badge.category].push(badge);
    return acc;
  }, {} as Record<string, BadgeType[]>) || {};

  const recentBadges = userBadges?.slice(0, 3) || [];

  if (badgesLoading || userBadgesLoading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Achievement Badges
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Unlock badges by exploring Sikkim's culture, nature, and heritage. Earn points and unlock exclusive experiences.
          </p>
        </div>
        
        {/* User Stats Overview */}
        {userStats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-primary" data-testid="text-total-points">
                {userStats.totalPoints}
              </div>
              <div className="text-sm text-muted-foreground">Total Points</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-secondary" data-testid="text-total-badges">
                {userStats.totalBadges}
              </div>
              <div className="text-sm text-muted-foreground">Badges Earned</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-accent" data-testid="text-total-checkins">
                {userStats.totalCheckIns}
              </div>
              <div className="text-sm text-muted-foreground">Check-ins</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-500" data-testid="text-total-photos">
                {userStats.totalPhotos}
              </div>
              <div className="text-sm text-muted-foreground">Photos Shared</div>
            </Card>
          </div>
        )}
        
        {/* Badge Categories Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {badgeCategories.map((category) => {
            const categoryBadges = badgesByCategory[category.id] || [];
            const earnedCount = categoryBadges.filter((badge: any) => earnedBadgeIds.has(badge.id)).length;
            const totalCount = categoryBadges.length;
            const progress = totalCount > 0 ? (earnedCount / totalCount) * 100 : 0;
            
            const IconComponent = category.icon;
            
            return (
              <Card key={category.id} className="p-6 text-center">
                <div className={cn("w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4", category.bgColor)}>
                  <IconComponent className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold mb-2">{category.label}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {category.id === 'explorer' && "Visit high-altitude destinations and sacred sites"}
                  {category.id === 'eco' && "Promote sustainable travel practices"}
                  {category.id === 'photo' && "Capture and share stunning moments"}
                  {category.id === 'community' && "Help fellow travelers and share knowledge"}
                </p>
                <div className={cn("font-medium mb-2", category.color)} data-testid={`text-${category.id}-progress`}>
                  {earnedCount}/{totalCount} Badges
                </div>
                <Progress value={progress} className="h-2" />
              </Card>
            );
          })}
        </div>
        
        {/* Recent Achievements */}
        {recentBadges.length > 0 && (
          <Card className="p-6 mb-8">
            <h3 className="text-xl font-semibold mb-6">Recent Achievements</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {recentBadges.map((userBadge: any) => (
                <div 
                  key={userBadge.id}
                  className="flex items-center p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                  data-testid={`recent-badge-${userBadge.badge.id}`}
                >
                  <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mr-4 badge-glow">
                    <Trophy className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">{userBadge.badge.name}</h4>
                    <p className="text-sm text-muted-foreground">{userBadge.badge.description}</p>
                    <div className="text-xs text-secondary">+{userBadge.badge.points} points</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
        
        {/* All Badges by Category */}
        {badgeCategories.map((category) => {
          const categoryBadges = badgesByCategory[category.id] || [];
          if (categoryBadges.length === 0) return null;
          
          const IconComponent = category.icon;
          
          return (
            <div key={category.id} className="mb-12">
              <div className="flex items-center mb-6">
                <IconComponent className={cn("h-6 w-6 mr-3", category.color)} />
                <h2 className="text-2xl font-bold">{category.label} Badges</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {categoryBadges.map((badge: any) => {
                  const isEarned = earnedBadgeIds.has(badge.id);
                  
                  return (
                    <Card 
                      key={badge.id}
                      className={cn(
                        "p-6 text-center transition-all duration-300 border-2",
                        isEarned ? "bg-accent/10 border-accent" : "border-border hover:border-muted-foreground",
                        rarityColors[badge.rarity as keyof typeof rarityColors]
                      )}
                      data-testid={`badge-${badge.id}`}
                    >
                      <div className={cn(
                        "w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
                        isEarned ? category.bgColor : "bg-muted"
                      )}>
                        <IconComponent className={cn(
                          "h-8 w-8",
                          isEarned ? "text-white" : "text-muted-foreground"
                        )} />
                        {isEarned && (
                          <div className="absolute">
                            <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          </div>
                        )}
                      </div>
                      
                      <h3 className={cn(
                        "font-semibold mb-2",
                        !isEarned && "text-muted-foreground"
                      )}>
                        {badge.name}
                      </h3>
                      
                      <p className={cn(
                        "text-sm mb-3",
                        isEarned ? "text-foreground" : "text-muted-foreground"
                      )}>
                        {badge.description}
                      </p>
                      
                      <div className="flex items-center justify-between text-xs">
                        <Badge variant={badge.rarity === 'legendary' ? 'default' : 'secondary'}>
                          {badge.rarity}
                        </Badge>
                        <span className={cn(
                          "font-medium",
                          isEarned ? category.color : "text-muted-foreground"
                        )}>
                          {badge.points} pts
                        </span>
                      </div>
                      
                      {!isEarned && badge.requirements && (
                        <div className="mt-3 p-2 bg-muted/50 rounded text-xs text-muted-foreground">
                          {badge.requirements.type === 'visit_count' && `Visit ${badge.requirements.count} ${badge.requirements.locations ? 'specific locations' : 'places'}`}
                          {badge.requirements.type === 'photo_upload' && `Upload ${badge.requirements.count} photos`}
                          {badge.requirements.type === 'checkin_count' && `Check in ${badge.requirements.count} times`}
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            </div>
          );
        })}
        
        {/* Community Leaderboard */}
        {leaderboard && leaderboard.length > 0 && (
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">Community Leaderboard</h3>
              <Button variant="outline" size="sm" data-testid="button-view-full-leaderboard">
                View All
              </Button>
            </div>
            
            <div className="space-y-3">
              {leaderboard.slice(0, 3).map((user: any) => (
                <div 
                  key={user.id}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-lg",
                    user.rank === 1 && "bg-accent/10",
                    user.rank === 2 && "bg-secondary/10", 
                    user.rank === 3 && "bg-primary/10"
                  )}
                  data-testid={`leaderboard-${user.rank}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm text-white",
                      user.rank === 1 && "bg-accent",
                      user.rank === 2 && "bg-secondary",
                      user.rank === 3 && "bg-primary"
                    )}>
                      {user.rank}
                    </div>
                    <div className="w-8 h-8 bg-muted rounded-full" />
                    <div>
                      <div className="font-medium text-sm" data-testid={`text-user-name-${user.rank}`}>
                        {user.username}
                      </div>
                      <div className="text-xs text-muted-foreground">Explorer</div>
                    </div>
                  </div>
                  <div className={cn(
                    "font-bold",
                    user.rank === 1 && "text-accent",
                    user.rank === 2 && "text-secondary",
                    user.rank === 3 && "text-primary"
                  )} data-testid={`text-user-points-${user.rank}`}>
                    {user.totalPoints} pts
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
