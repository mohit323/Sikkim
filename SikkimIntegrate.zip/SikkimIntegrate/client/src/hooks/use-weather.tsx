import { useQuery } from "@tanstack/react-query";

export interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  forecast: Array<{
    date: string;
    high: number;
    low: number;
    condition: string;
  }>;
}

export function useWeather(location: string = "Gangtok") {
  return useQuery({
    queryKey: ["/api/weather", location],
    enabled: !!location,
    staleTime: 10 * 60 * 1000, // 10 minutes
    gcTime: 30 * 60 * 1000, // 30 minutes
  });
}

export function useRoadConditions(route?: string) {
  return useQuery({
    queryKey: ["/api/road-conditions", route].filter(Boolean),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 15 * 60 * 1000, // 15 minutes
  });
}

export function useAltitudeWeather(altitude: number) {
  return useQuery({
    queryKey: ["/api/altitude-weather", altitude],
    enabled: altitude > 0,
    staleTime: 30 * 60 * 1000, // 30 minutes
    gcTime: 60 * 60 * 1000, // 1 hour
  });
}
