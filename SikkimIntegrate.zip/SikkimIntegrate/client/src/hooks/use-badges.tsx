import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const MOCK_USER_ID = "user_123";

export function useBadges(userId: string = MOCK_USER_ID) {
  const queryClient = useQueryClient();

  // Get all available badges
  const { 
    data: allBadges, 
    isLoading: badgesLoading, 
    error: badgesError 
  } = useQuery({
    queryKey: ["/api/badges"],
  });

  // Get user's earned badges
  const { 
    data: userBadges, 
    isLoading: userBadgesLoading, 
    error: userBadgesError 
  } = useQuery({
    queryKey: ["/api/users", userId, "badges"],
  });

  // Get user stats
  const { 
    data: userStats, 
    isLoading: statsLoading, 
    error: statsError 
  } = useQuery({
    queryKey: ["/api/users", userId, "stats"],
  });

  // Award badge mutation
  const awardBadgeMutation = useMutation({
    mutationFn: async ({ badgeId, progress }: { badgeId: string; progress?: Record<string, number> }) => {
      const response = await apiRequest("POST", "/api/badges/award", {
        userId,
        badgeId,
        progress
      });
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch user badges and stats
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "badges"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "stats"] });
    }
  });

  // Update badge progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async ({ 
      badgeId, 
      progress 
    }: { 
      badgeId: string; 
      progress: Record<string, number> 
    }) => {
      const response = await apiRequest("PUT", `/api/badges/${badgeId}/progress`, {
        userId,
        progress
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "badges"] });
    }
  });

  // Calculate badge progress
  const calculateBadgeProgress = (badge: any, userProgress?: Record<string, number>) => {
    if (!badge.requirements) return { current: 0, total: 1, percentage: 0 };

    const { type, count } = badge.requirements;
    const current = userProgress?.[type] || 0;
    
    return {
      current: Math.min(current, count),
      total: count,
      percentage: Math.min((current / count) * 100, 100)
    };
  };

  // Get badges by category
  const getBadgesByCategory = (category: string) => {
    return allBadges?.filter((badge: any) => badge.category === category) || [];
  };

  // Check if user has earned a badge
  const hasEarnedBadge = (badgeId: string) => {
    return userBadges?.some((userBadge: any) => userBadge.badge.id === badgeId) || false;
  };

  // Get recent badges (last 5)
  const getRecentBadges = () => {
    return userBadges?.slice(0, 5) || [];
  };

  // Get badge categories with progress
  const getBadgeCategories = () => {
    const categories = [
      { id: "explorer", label: "Explorer", color: "text-primary" },
      { id: "eco", label: "Eco Warrior", color: "text-secondary" },
      { id: "photo", label: "Photographer", color: "text-accent" },
      { id: "community", label: "Community", color: "text-purple-500" },
    ];

    return categories.map(category => {
      const categoryBadges = getBadgesByCategory(category.id);
      const earnedCount = categoryBadges.filter((badge: any) => hasEarnedBadge(badge.id)).length;
      const totalCount = categoryBadges.length;
      
      return {
        ...category,
        earnedCount,
        totalCount,
        progress: totalCount > 0 ? (earnedCount / totalCount) * 100 : 0
      };
    });
  };

  // Track badge-worthy action
  const trackAction = (actionType: string, data?: any) => {
    // This would be called when user performs actions that contribute to badges
    // e.g., trackAction('check_in', { attractionId: 'xyz' })
    // e.g., trackAction('photo_upload', { location: 'Gangtok' })
    
    console.log("Badge action tracked:", actionType, data);
    
    // In a real implementation, this would trigger badge progress updates
    // and potentially award new badges automatically
  };

  return {
    // Data
    allBadges,
    userBadges,
    userStats,
    
    // Loading states
    isLoading: badgesLoading || userBadgesLoading || statsLoading,
    
    // Errors
    error: badgesError || userBadgesError || statsError,
    
    // Mutations
    awardBadge: awardBadgeMutation.mutate,
    updateProgress: updateProgressMutation.mutate,
    isAwarding: awardBadgeMutation.isPending,
    isUpdating: updateProgressMutation.isPending,
    
    // Utility functions
    calculateBadgeProgress,
    getBadgesByCategory,
    hasEarnedBadge,
    getRecentBadges,
    getBadgeCategories,
    trackAction
  };
}
