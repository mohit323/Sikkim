import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from "@/components/layout/navigation";
import Home from "@/pages/home";
import Attractions from "@/pages/attractions";
import Guides from "@/pages/guides";
import Badges from "@/pages/badges";
import Transport from "@/pages/transport";
import NotFound from "@/pages/not-found";
import ChatbotWidget from "@/components/chatbot/chatbot-widget";
import BadgeOverlay from "@/components/badges/badge-overlay";
import EmergencyModal from "@/components/emergency/emergency-modal";

function Router() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/attractions" component={Attractions} />
        <Route path="/guides" component={Guides} />
        <Route path="/badges" component={Badges} />
        <Route path="/transport" component={Transport} />
        <Route component={NotFound} />
      </Switch>
      
      {/* Global Components */}
      <ChatbotWidget />
      <BadgeOverlay />
      <EmergencyModal />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
